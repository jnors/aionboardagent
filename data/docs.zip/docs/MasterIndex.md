# FrameTech Onboarding Document Index

This index lists all onboarding-related documents, their contents, and key topics.

---

## 1. Welcome & General Orientation

**File:** `WelcomeGuide.md`  
**Contents:** Overview of first week schedule, intro to product, HR onboarding, shadowing sessions, main contact points, IT help contact.  
**Topics:**  
- First week expectations  
- Day-by-day activities  
- HR session details  
- IT support email

**File:** `FirstWeekChecklist.md`  
**Contents:** Checklist of activities for each day of the first week.  
**Topics:**  
- Laptop setup  
- Joining Slack channels  
- Department intros  
- Mandatory training  
- Pairing with buddy

---

## 2. Policies & Company Information

**File:** `Policies.md`  
**Contents:** Summary of company working hours, remote work policy, communication tools, expense reimbursement process.  
**Topics:**  
- Core hours  
- Remote-first policy  
- Slack vs Email usage  
- Expense submission and deadlines

**File:** `OrgChartOverview.md`  
**Contents:** Company department structure and leadership.  
**Topics:**  
- Department names and functions  
- Department managers

**File:** `Company_Values.md`
**Contents:** Mission, vision, core values, and cultural practices.  
**Topics:**  
- Mission & Vision  
- Transparency, Collaboration, Customer Focus, Continuous Learning  
- Cultural activities

---

## 3. Benefits & Perks

**File:** `BenefitsOverview.md`  
**Contents:** Health & insurance benefits, time off, learning stipend, extras.  
**Topics:**  
- Health, dental, vision coverage  
- Vacation days & holidays  
- Learning budget  
- Remote work setup budget

---

## 4. IT & Tools

**File:** `IT_Onboarding.md`  
**Contents:** Account setup, VPN access, essential tool installation, Wi-Fi info.  
**Topics:**  
- Google Workspace login  
- VPN setup (Cisco AnyConnect)  
- Required software list  
- Wi-Fi credentials

**File:** `Tool_Playbook.md`
**Contents:** Slack channel guide, best practices, integrations, support contacts.  
**Topics:**  
- Channel purposes  
- Thread usage  
- Slack integrations

---

## 5. Role-Specific Guides

**File:** `EngineeringOnboarding.md`  
**Contents:** Access setup, coding standards, deployment process, first 30 days goals.  
**Topics:**  
- GitHub access  
- Code review process  
- Release schedule

---

## 6. Security & Compliance

**File:** `SecurityGuidelines.md`  
**Contents:** Account and device security, data handling, reporting suspicious activity.  
**Topics:**  
- 2FA setup  
- Password management  
- Data classification

---

## 7. Processes & Workflows

**File:** `ExpenseApprovalWorkflow.md` 
**Contents:** Expense submission and approval steps, guidelines.  
**Topics:**  
- Receipt submission  
- Approval hierarchy  
- Timeline for reimbursement

**File:** `QuickGuides.md` 
**Contents:** How-to for common tasks.  
**Topics:**  
- Booking meeting rooms  
- Updating email signatures  
- Requesting office supplies

---


## 8. Product & Customer Knowledge

**File:** `ProductCheatSheet.md`  
**Contents:** Overview of company product(s), key features, target customers, competitive edge.  
**Topics:**  
- Feature summaries  
- Target industries  
- Differentiators


---

## 9. Career Growth

**File:** `CareerDevelopment.md`
**Contents:** Performance reviews, promotion criteria, learning opportunities.  
**Topics:**  
- Review cycle  
- Promotion requirements  
- Learning resources

---

## 10. FAQs

**File:** `CommonFAQs.md`  
**Contents:** Answers to frequent new hire questions.  
**Topics:**  
- Badge access  
- Payslip location  
- Equipment requests  
- Sick leave reporting  
- IT support contacts

---

**Note:** All “*(NEW)*” files should be created and added to the embedding pipeline to expand the onboarding agent’s knowledge.
