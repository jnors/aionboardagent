# Welcome to the Team 🎉

We’re excited to have you at Frame Technologies!

Here's what to expect during your first week:

- **Day 1**: IT setup and team intros
- **Day 2**: Intro to our product and customers
- **Day 3**: Onboarding session with HR
- **Day 4-5**: Shadow team members and complete your first small task

Your manager will be your main point of contact. Feel free to ask questions!

For any IT issues, email `helpdesk@frametech.io`.

