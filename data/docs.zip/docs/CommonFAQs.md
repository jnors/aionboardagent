FrameTech New Hire FAQs

Q: Where do I get my badge?
A: HR will provide it during your in-office visit.

Q: How do I access payslips?
A: Through the BambooHR portal.

Q: Who do I talk to about equipment?
A: Submit an IT ticket via Slack #it-support.

Q: What’s our preferred calendar tool?
A: Google Calendar.

Q: How do I report sick leave?
A: Email sick@frametech.io before 10am.

Q: How do I get IT Support?
A: Just contact the team via Slack #it-support or send an email to it@frametech.com
