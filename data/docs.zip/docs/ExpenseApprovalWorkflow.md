# Expense Approval Workflow – FrameTech

## Steps
1. Submit receipt via the Expense Portal.
2. Your manager reviews & approves.
3. Finance processes reimbursement by the 15th of the following month.

## Guidelines
- Travel expenses require prior approval from your manager.
- Any purchase over €500 requires CFO approval.
