IT Onboarding – Initial Setup

1. Your FrameTech account credentials have been emailed.
2. Log into your FrameTech Google Workspace.
3. VPN access:
   - Download Cisco AnyConnect from our portal
   - Use your FrameTech email to log in
4. Tools to install:
   - Slack
   - Visual Studio Code
   - GitHub Desktop
5. Wi-Fi: Connect to `FrameTech-Guest` / password: Welcome123
