Organizational Overview – FrameTech

We are structured across 4 core departments:

1. Engineering
   - Backend, Frontend, DevOps, QA
   - Managed by João Costa

2. Product & Design
   - PMs, UX, UI
   - Managed by Maria Lopes

3. Revenue
   - Sales, Customer Success, Partnerships
   - Managed by Rui Almeida

4. Operations
   - HR, Finance, Legal, IT
   - Managed by Ana Silva
