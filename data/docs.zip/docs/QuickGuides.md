# Quick Guides – FrameTech

## How to Book a Meeting Room
- Use Google Calendar and invite the room resource.

## How to Update Your Email Signature
- Go to Gmail Settings → See all settings → General → Signature.

## How to Request Office Supplies
- Submit a request in #ops-support or via ops@frametech.io.
