# Your First Week Checklist ✅

## Day 1
- [ ] Laptop setup
- [ ] Join #new-hires Slack channel
- [ ] Read the Welcome Guide

## Day 2–3
- [ ] Intro sessions with each department
- [ ] Review company OKRs
- [ ] Complete mandatory training

## Day 4–5
- [ ] Pair with your buddy
- [ ] Review first small project
- [ ] Join Friday all-hands
