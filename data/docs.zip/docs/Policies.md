# Company Policies Summary

## Working Hours
- Core hours: 10am to 4pm (flexible start and end)

## Remote Work
- We are a remote-first company.
- Employees can work from anywhere in the EU time zone.

## Communication
- Slack for internal
- Email for external

## Expense Reimbursement
- Submit receipts using the Expense Portal
- Monthly deadline: 25th

