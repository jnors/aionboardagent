# Our Values – FrameTech

## Mission
To deliver world-class technology that empowers our customers to succeed.

## Vision
A future where technology bridges gaps and fosters innovation globally.

## Core Values
1. **Transparency** – Share openly with colleagues and clients.
2. **Collaboration** – Work together across teams and disciplines.
3. **Customer Focus** – Make decisions with the customer’s needs in mind.
4. **Continuous Learning** – Invest in personal and professional growth.

## Culture in Action
- Weekly all-hands for open Q&A.
- Monthly “lunch & learn” sessions.
