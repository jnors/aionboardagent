# Benefits Overview – FrameTech

## Health & Insurance
- Private health insurance from day 1
- Dental and vision included
- Mental health support via MindEase

## Time Off
- 25 vacation days
- Birthday off
- 12 company holidays

## Learning & Development
- Annual learning stipend: €1000
- Internal mentoring program
- Access to Coursera & Pluralsight

## Extras
- Remote work setup budget (€300)
- Spotify/Netflix on us 🎧🍿
