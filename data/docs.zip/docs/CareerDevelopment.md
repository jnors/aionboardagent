# Career Development at FrameTech

## Performance Reviews
- Twice a year (June & December).
- Focus on both achievements and growth areas.

## Promotion Criteria
- Demonstrated mastery of current role.
- Positive peer and manager feedback.
- Contribution to cross-team projects.

## Learning Opportunities
- €1000 annual learning stipend.
- Access to Coursera, Pluralsight, and internal training.
